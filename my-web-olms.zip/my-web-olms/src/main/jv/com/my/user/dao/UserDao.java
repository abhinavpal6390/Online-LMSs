package com.my.user.dao;

public class UserDao {
	
	private String jdbcURL="jdbc:mysql://localhost:30006/userappdb";
	private String jdbcUserName="root";
	private String jdbcPassword="root";
	
	
	private static final String INSERT_USER_SQL="INSERT INTO users"+"("
	
	
	

}
